
def compute_alerts_for_entity(trade_df, currency_df):
    old_map = currency_df.set_index("CCY")["Old_Threshold"].to_dict()
    prop_map = currency_df.set_index("CCY")["Proposed_Threshold"].to_dict()
    final_map = currency_df.set_index("CCY")["Final_Threshold"].to_dict()
    group_map = currency_df.set_index("CCY")["Final_Group"].to_dict()

    def get_max_thresh(instr, mapping):
        try:
            base, quote = instr.split("/")
            return max(mapping.get(base, 0), mapping.get(quote, 0))
        except:
            return 0

    def get_group(instr):
        try:
            base, quote = instr.split("/")
            return max(group_map.get(base, "Group 1"), group_map.get(quote, "Group 1"))
        except:
            return "Group 1"

    trade_df["Threshold_Old"] = trade_df["Instrument"].map(lambda x: get_max_thresh(x, old_map))
    trade_df["Threshold_Proposed"] = trade_df["Instrument"].map(lambda x: get_max_thresh(x, prop_map))
    trade_df["Threshold_Final"] = trade_df["Instrument"].map(lambda x: get_max_thresh(x, final_map))

    trade_df["Alert_Old"] = trade_df["deviation_percent"] > trade_df["Threshold_Old"]
    trade_df["Alert_Proposed"] = trade_df["deviation_percent"] > trade_df["Threshold_Proposed"]
    trade_df["Alert_Final"] = trade_df["deviation_percent"] > trade_df["Threshold_Final"]
    trade_df["Group"] = trade_df["Instrument"].map(get_group)
    return trade_df
