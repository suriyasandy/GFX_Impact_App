
import pandas as pd

def generate_group_summary(currency_df, trade_df):
    group_summary = currency_df.groupby("Final_Group")["CCY"].agg(list).reset_index().rename(columns={"Final_Group": "Group", "CCY": "Currencies"})
    group_summary["Currencies"] = group_summary["Currencies"].apply(lambda x: ", ".join(sorted(x)))

    alert_summary = trade_df.groupby("Group")[["Alert_Old", "Alert_Proposed", "Alert_Final"]].sum().reset_index()
    alert_summary["Total_Trades"] = trade_df.groupby("Group")["Instrument"].count().values

    merged = pd.merge(group_summary, alert_summary, on="Group", how="left")
    return merged

def generate_legal_entity_summary(alert_results):
    entity_alerts = []
    for entity, df in alert_results.items():
        counts = {
            "LegalEntity": entity,
            "Alert_Old": df["Alert_Old"].sum(),
            "Alert_Proposed": df["Alert_Proposed"].sum(),
            "Alert_Final": df["Alert_Final"].sum()
        }
        entity_alerts.append(counts)
    return pd.DataFrame(entity_alerts)

def generate_audit_trail(currency_df):
    audit_df = currency_df.copy()
    audit_df["Changed?"] = audit_df["Final_Threshold"] != audit_df["Proposed_Threshold"]
    audit_df["Change %"] = ((audit_df["Final_Threshold"] - audit_df["Proposed_Threshold"]) / audit_df["Proposed_Threshold"]).round(3)
    return audit_df
