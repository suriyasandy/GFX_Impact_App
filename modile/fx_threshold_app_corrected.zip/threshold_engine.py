
def process_threshold_file(df):
    group_bounds = df.groupby("Proposed_Group")["Proposed_Threshold"].first().sort_values().to_dict()

    def assign_group(th):
        for group, bound in group_bounds.items():
            if th <= bound:
                return group
        return list(group_bounds.keys())[-1]

    df["Final_Threshold"] = df["Proposed_Threshold"]
    df["Final_Group"] = df["Final_Threshold"].apply(assign_group)
    return df
